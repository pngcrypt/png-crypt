yarovaya.jpg - исходное изображение
dama-s-paketom.jpg - исходное изображение

yara-yoba.png - изображение с запакованным файлом yoba.png

	распаковка: png-crypt -d yara-yoba.png


miski-na-severe_webm.png - изображение с запакованным webm (т.к. webm большой, при кодировании использовалось -B:5 -a:1 )

	распаковка: png-crypt -d miski-na-severe_webm.png


svoi_zakony_crypt-webm.png - изображение с запакованным webm, зашифровано паролем "ramenskoe"	

	распаковка: png-crypt -d -p:ramenskoe svoi_zakony_crypt-webm.png

